This example is explained in the tutorial

http://jacamo.sourceforge.net/tutorial/coordination
